<?php $__env->startSection('header'); ?>
    @parent
    header
<?php $__env->stopSection(); ?>


<?php $__env->startSection('sidebar'); ?>
    sidebar
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    content

    <?php /*<!-- 1. 模板中输出PHP变量 -->*/ ?>
    <?php /*<p><?php echo e($name); ?></p>*/ ?>

    <?php /*<!-- 2. 模板中调用PHP代码 -->*/ ?>
    <?php /*<p><?php echo e(time()); ?></p>*/ ?>
    <?php /*<p><?php echo e(date('Y-m-d H:i:s', time())); ?></p>*/ ?>

    <?php /*<p><?php echo e(in_array($name, $arr) ? 'true': 'false'); ?></p>*/ ?>
    <?php /*<p><?php echo e(var_dump($arr)); ?></p>*/ ?>

    <?php /*<p><?php echo e(isset($name) ? $name : 'default'); ?></p>*/ ?>
    <?php /*<p><?php echo e(isset($name1) ? $name1 : 'default'); ?></p>*/ ?>

    <?php /*<!-- 3. 原样输出 -->*/ ?>
    <?php /*<p>{{ $name }}</p>*/ ?>

     <?php /*4. 模板中的注释 */ ?>


     <?php /*5. 引入子视图 include */ ?>
    <?php /*<?php echo $__env->make('student.common1', ['message' => '我是错误信息'], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>*/ ?>


    <br>
    <?php if($name == 'sean'): ?>
        I'm sean
    <?php elseif($name == 'imooc'): ?>
        I'm imooc
    <?php else: ?>
        Who am I?
    <?php endif; ?>

    <br>
    <?php if(in_array($name, $arr)): ?>
        true
    <?php else: ?>
        false
    <?php endif; ?>

    <br>
    <?php if ( ! ($name != 'sean')): ?>
        I'm sean
    <?php endif; ?>

    <br>
    <?php /*<?php for($i=0; $i < 10; $i++): ?>*/ ?>
        <?php /*<p><?php echo e($i); ?></p>*/ ?>
    <?php /*<?php endfor; ?>*/ ?>

    <br>
    <?php /*<?php foreach($students as $student): ?>*/ ?>
        <?php /*<p><?php echo e($student->name); ?></p>*/ ?>
    <?php /*<?php endforeach; ?>*/ ?>


    <?php /*<?php $__empty_1 = true; foreach($students as $student): $__empty_1 = false; ?>*/ ?>
        <?php /*<p><?php echo e($student->name); ?></p>*/ ?>
    <?php /*<?php endforeach; if ($__empty_1): ?>*/ ?>
        <?php /*<p>null</p>*/ ?>
    <?php /*<?php endif; ?>*/ ?>




    <a href="<?php echo e(url('url')); ?>">url()</a>
    <br>
    <a href="<?php echo e(action('StudentController@urlTest')); ?>">action()</a>
    <br>
    <a href="<?php echo e(route('url')); ?>">route()</a>










<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>