member/info blade

<?php echo e($name); ?> <?php echo e($age); ?>