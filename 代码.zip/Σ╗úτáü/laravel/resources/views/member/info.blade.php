member/info blade

{{$name}} {{$age}}